package main;

public enum ID {    
    Player(),
    Block(),
    Wall(),
    Mine(),
    Bullet(),
    Enemy(),
    Enemy1(),
    EnemyBullet(),
    Enemy1Bullet(),
    Life();
}
